'''
Android module
==============

'''

# legacy import
from android._android import *  # noqa: F401, F403
